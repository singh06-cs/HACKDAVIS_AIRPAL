#ifndef APPCONSTANTS_H
#define APPCONSTANTS_H

#include <QString>

namespace AppConstants
{
    const QString ServerIp = "75.33.176.134";
    const int ServerPort = 2527;

    const QString DeviceId = "S23_PLUS_1";

    const double DefaultLatitude = 38.5449;
    const double DefaultLongitude = -121.7405;
}

#endif
