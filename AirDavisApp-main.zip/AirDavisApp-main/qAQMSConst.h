#ifndef QAQMSCONST_H
#define QAQMSCONST_H

#include <QString>

const QString QAQMS_IPA = "192.826.8134.134";
const int QAQMS_PORT = 6769;
const QString QAQMS_DATA_FILE = "readings.json";

#endif
