QT -= gui

CONFIG += c++11 console
CONFIG -= app_bundle

QT += core network

SOURCES += \
    src/main.cpp \
    src/qAQMS.cpp

HEADERS += \
    src/qAQMS.h \
    src/qAQMSConst.h

INCLUDEPATH += src

qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target